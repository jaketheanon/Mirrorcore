# Mirrorcore

A local-first Python CLI application that serves as a private persistent reasoning assistant.

## Overview

Mirrorcore models your thinking patterns, decision logic, troubleshooting habits, and communication style to provide personalized assistance. It operates as a continuously learning reasoning agent with persistent identity modeling, episodic memory, and reflective learning.

## Features

- **Initial Assessment** - Branching questionnaire to understand your reasoning patterns
- **Terminal Troubleshooting** - Analyze and diagnose command-line issues using your historical problem-solving patterns
- **Decision Reasoning** - Get decision support based on your values, risk tolerance, and decision style
- **Learning from Conversations** - Extract and model reasoning patterns from ongoing interactions
- **Persona Modeling** - Continuously refine understanding of your communication style and cognitive preferences

## Architecture

Mirrorcore follows a modular agent-based architecture with specialized agents for different capabilities:

- **Intake Agent** - Initial user assessment and scenario-based profiling
- **Memory Agent** - Episodic memory extraction, retrieval, and updates
- **Persona Agent** - Voice, values, and decision-making style modeling
- **Terminal Agent** - Command-line parsing, diagnosis, and resolution
- **Decision Agent** - Reasoning support and tradeoff analysis
- **LLM Agent** - Language model interaction abstraction

## Installation
Mirrorcore uses Python's standard library only. No external dependencies required.

### Option 1: Run from source
```bash
# Clone or download repository
git clone https://github.com/your-repo/mirrorcore.git
cd mirrorcore

# Run directly with Python module
PYTHONPATH=src python3 -m mirrorcore --help
```

### Option 2: Install in development mode
```bash
# Clone or download repository
git clone https://github.com/your-repo/mirrorcore.git
cd mirrorcore

# Install in development mode (creates editable install)
pip install -e .

### Dependencies
- Python 3.10+
- prompt-toolkit>=0.5.0 (for enhanced terminal editing in interactive mode)

### Now you can run from anywhere
```bash
mirrorcore --help
```

## First-Time Setup

1. **Initialize Database**
   ```bash
   mirrorcore init
   ```
   This runs the initial reasoning assessment to establish your persona profile.

2. **Start Interactive Session**
   ```bash
   mirrorcore interactive
   ```
   Begin conversing with Mirrorcore. It will learn from your interaction patterns over time.

3. **Check Status**
   ```bash
   mirrorcore status
   ```
   View system status, persona traits, and learning progress.

## Available Commands

- `mirrorcore init` - Run initial reasoning assessment
- `mirrorcore interactive` - Start interactive learning session
- `mirrorcore debug "<command>"` - Debug terminal issues
- `mirrorcore debug-outcome` - Record outcome of debugging attempt
- `mirrorcore debug-history [incident_type]` - View ranked fix history for incident types
- `mirrorcore analyze-log` - Analyze raw terminal output, logs, or stack traces
- `mirrorcore decide "<question>"` - Get decision assistance
- `mirrorcore profile` - View your persona profile
- `mirrorcore assess` - Continue previous assessment
- `mirrorcore memory` - Memory management
- `mirrorcore status` - Show system status
- `mirrorcore config` - Configuration management

## Terminal Fix Outcome Tracking

Mirrorcore now tracks outcomes of your troubleshooting attempts to build practical fix memory over time, with deterministic ranking and reuse.

### Recording Outcomes

After debugging an issue, you can record what happened:

```bash
# Record outcome of most recent debugging attempt
mirrorcore debug-outcome
```

This will show you recent incidents to select from, then prompt for:
- What fix you tried
- What was the result (success/failed/partial/unknown)
- What was the confirmed root cause (optional)
- Any additional notes

### Viewing Fix History

```bash
# View ranked fix history for all incident types
mirrorcore debug-history

# View ranked fix history for specific incident type
mirrorcore debug-history docker_container_restart
```

This shows:
- **Ranked fixes** by success rate and recency
- **Success/failure counts** for each approach
- **Normalization** of similar fix attempts
- **Scoring** based on deterministic weights

Example output:
```
Ranked fix history for: docker_container_restart
==================================================
1. check docker logs
   Score: 25.0
   Success: 3, Partial: 1, Failed: 0
   Total attempts: 4
   Last tried: 2024-03-11 15:30:22
   Variations: 4 attempts recorded

2. restart container with different config
   Score: 15.0
   Success: 1, Partial: 0, Failed: 2
   Total attempts: 3
   Last tried: 2024-03-10 09:15:45
   Variations: 3 attempts recorded
```

### Deterministic Ranking System

Mirrorcore ranks fixes using a transparent scoring system:

- **Success weight**: +10.0 points
- **Partial success weight**: +5.0 points  
- **Failure weight**: -2.0 points
- **Recency bonus**: +0.1 points (for attempts within 30 days)
- **No success penalty**: -5.0 points (if no successful attempts)

### Historical Context in Responses

When Mirrorcore recognizes a known incident type, it incorporates ranked historical guidance:

- **Most successful approach**: Shows the highest-scoring fix with explanation
- **Alternative successful options**: Shows other successful approaches
- **Commonly failed approaches**: Warns about approaches with high failure rates
- **Incident-type filtering**: Only shows history for the same incident type

Example enhanced response:
```
I recognize this as a Docker Container Restart issue. Let me provide targeted guidance:

Most likely causes:
1. Resource exhaustion (memory/CPU)
2. Application crash/exception
3. Health check failures

First checks to run:
1. Check container logs: `docker logs container_name`
2. Monitor resource usage: `docker stats container_name`
3. Inspect container state: `docker inspect container_name`

Based on previous outcomes for this issue:
Most successful approach: check docker logs
  Reason: 3 successful, 0 failed attempts
Other successful approaches:
  2. restart container with different config (1 success)
  3. check resource limits (1 success)

Approaches that typically fail:
  • rebuild container without checking logs (2 failed)

Low-risk initial actions:
• Check recent application changes or deployments
• Verify external service connectivity

These steps should help identify the root cause. Let me know what you discover!
```

This creates a feedback loop where your successful solutions become more targeted over time, moving from generic first-pass suggestions to practical, experience-based guidance with deterministic ranking.

## Raw Log Analysis

Mirrorcore can now analyze raw terminal output, logs, and stack traces directly to extract error signals and provide targeted troubleshooting guidance with command-aware context detection.

### Analyzing Raw Logs

```bash
# Analyze raw terminal output, logs, or stack traces
mirrorcore analyze-log
```

This will prompt you to paste multiline terminal output:

```
📋 Paste raw terminal output, logs, or stack traces
   End input with Ctrl+D (Unix) or Ctrl+Z then Enter (Windows)
   Or type 'exit' to cancel
============================================================
```

### Command-Aware Detection

Mirrorcore now detects command context to improve incident detection accuracy:

**Supported Command Families:**
- **pip/python**: `pip install`, `pip uninstall`, `python script.py`
- **docker**: `docker run`, `docker logs`, `docker compose up`
- **systemctl/journalctl**: `systemctl start`, `journalctl -u service`
- **git**: `git push`, `git pull`, `git clone`
- **npm/node**: `npm install`, `npm run`, `node script.js`
- **chmod/chown/sudo**: `chmod 755`, `chown user:group`, `sudo command`
- **curl/wget**: `curl http://example.com`, `wget file.tar.gz`
- **ssh/scp**: `ssh user@host`, `scp file user@host:`

### Enhanced Incident Detection

Command context improves incident detection by providing confidence boosts:

| Incident Type | Command Context | Confidence Boost |
|---------------|------------------|------------------|
| `pip_permission_denied` | `pip install` | +0.15 |
| `docker_container_restart` | `docker logs` | +0.15 |
| `systemd_service_failed` | `systemctl start` | +0.15 |
| `git_auth_remote` | `git push` | +0.15 |
| `npm_permission_denied` | `npm install` | +0.15 |
| `command_not_found` | Any detected command | +0.10 |

### Example Command-Aware Analysis

```bash
$ mirrorcore analyze-log
📋 Paste raw terminal output, logs, or stack traces
   End input with Ctrl+D (Unix) or Ctrl+Z then Enter (Windows)
   Or type 'exit' to cancel
============================================================
pip install requests
ERROR: Could not install packages due to an OSError: Permission denied
^D

============================================================
🔍 LOG ANALYSIS RESULTS
============================================================

📊 Detected Error Category: ERROR
🔑 Keywords Found: error, failed, permission_denied

⚡ Detected Command: pip install requests
   Subsystem: pip
   Context: Line 1: pip command detected

📝 Relevant Error Lines (1):
   1. ERROR: Could not install packages due to an OSError: Permission denied

📄 Summary: Detected error: ERROR: Could not install packages due to an OSError: Permission denied

🎯 INCIDENT DETECTION
----------------------------------------
✅ Recognized Incident Type: pip_permission_denied
   Confidence: 0.95
   Command Context: pip command detected
   Context Boost: +0.15 confidence

💡 HISTORICAL FIX GUIDANCE
----------------------------------------
Most successful approach: pip install --user package_name
   Reason: 3 successful, 0 failed attempts
Approaches that typically fail:
   • pip install without virtual environment (2 failed)

🛠️ TARGETED TROUBLESHOOTING
----------------------------------------
I recognize this as a Pip Permission Denied issue. Let me provide targeted guidance:
[Standard incident response with historical context...]
```

### Error Signal Detection

The log parser extracts meaningful diagnostic lines using deterministic pattern matching:

**Detected Error Signals:**
- **Traceback**: Python stack traces and exception call chains
- **Exception**: General exceptions and error conditions
- **Error**: General error messages and failures
- **Failed**: Operation failures and build/deployment issues
- **Permission Denied**: Access and permission issues
- **Command Not Found**: Missing commands and PATH issues
- **Connection Refused**: Network connectivity problems
- **Timeout**: Operation timeouts and delays
- **DNS**: Domain name resolution failures
- **Module Not Found**: Python import and module issues
- **Import Error**: Python import failures
- **Service Failed**: Systemd and service management issues
- **Exited with Code**: Process exit codes and termination
- **Segmentation Fault**: Memory corruption and crashes
- **Syntax Error**: Code syntax and parsing issues
- **Parse Error**: Configuration and format problems

### Analysis Process

1. **Command Detection**: Identifies command patterns in first 5 lines
2. **Signal Extraction**: Identifies error lines using keyword and regex patterns
3. **Noise Filtering**: Ignores timestamps, empty lines, and generic info messages
4. **Context Preservation**: Maintains relevant context lines around errors
5. **Enhanced Incident Detection**: Maps extracted signals + command context to known incident types
6. **Historical Reuse**: Retrieves ranked fixes for recognized incidents
7. **Structured Output**: Provides categorized analysis with command context

### Integration with Existing Features

The analyze-log command integrates seamlessly with existing Mirrorcore features:

- **Incident Signatures**: Uses enhanced signature detection with command context
- **Ranked Historical Fixes**: Reuses successful fixes when incident type matches
- **Database Storage**: Stores analysis results with command context for learning
- **Outcome Recording**: Works with debug-outcome to record fix results
- **CLI Integration**: Fits naturally into existing command structure

### Supported Input Types

- **Command + Error**: `pip install package` followed by error output
- **Python Tracebacks**: Full exception stack traces with file and line numbers
- **System Logs**: Service status, journalctl output, and system messages
- **Build Output**: Compilation errors, test failures, and deployment issues
- **Network Errors**: Connection refused, timeout, and DNS resolution failures
- **Permission Issues**: Access denied and authorization errors
- **Command Failures**: Missing commands and execution errors

### Fallback Behavior

When no command is detected:
- Uses existing log parsing behavior
- Continues extracting signal lines
- Performs incident detection normally
- Provides structured fallback analysis

## Assisted Outcome Capture

Mirrorcore now offers assisted outcome capture to reduce friction in learning by prompting to record troubleshooting results immediately after analysis sessions, while preserving the manual `debug-outcome` command.

### Automatic Outcome Prompts

After troubleshooting interactions or analyze-log sessions, Mirrorcore may offer:

```
============================================================
🎯 OUTCOME CAPTURE
============================================================
Did one of these suggested fixes solve the issue? [y/N]

Suggested fixes from this session:
  1. pip install --user package_name
  2. Create/activate virtual environment
  3. Check if package already installed system-wide

If you'd like to record the outcome now, type 'y' and I'll collect:
  • Which fix you attempted
  • Result (success/failed/partial/unknown)
  • Confirmed root cause (optional)
  • Additional notes (optional)

You can also use 'mirrorcore debug-outcome' anytime to record outcomes.
```

### When Outcome Capture is Offered

Mirrorcore only prompts for outcome capture when:

- **Recognized troubleshooting incidents** are analyzed in interactive mode
- **Structured incident responses** are generated from analyze-log sessions
- **Targeted troubleshooting guidance** is provided with specific incident types

The system does not prompt after casual conversations or non-technical interactions.

### Outcome Collection Process

If you choose to record an outcome (`y`), Mirrorcore collects:

1. **Fix Selection**: Choose from suggested fixes or specify your own
2. **Result Status**: 
   - `success` - Fix completely resolved the issue
   - `partial` - Fix helped but issue persists
   - `failed` - Fix didn't work or made things worse
   - `unknown` - Not sure if it worked
3. **Confirmed Root Cause** (optional): What actually caused the issue
4. **Additional Notes** (optional): Any relevant observations

### Confirmation and Storage

```
✅ Outcome recorded successfully!
   Incident ID: abc123-def456-ghi789
   Attempted fix: pip install --user package_name
   Result: success
   Outcome ID: xyz987-uvw654-rst321

This information will help improve future troubleshooting suggestions.
```

### Manual Outcome Recording

The manual `debug-outcome` command remains available for:

- Recording outcomes from sessions without automatic prompts
- Adding outcomes for issues resolved outside of Mirrorcore
- Updating or correcting previously recorded outcomes

```bash
# Manual outcome recording (always available)
mirrorcore debug-outcome

# Automatic outcome capture (after qualifying sessions)
mirrorcore                # Interactive mode with automatic prompts
mirrorcore analyze-log     # Log analysis with automatic prompts
```

### Learning Integration

Recorded outcomes integrate with Mirrorcore's learning system:

- **Ranked Historical Fixes**: Successful fixes rise in rankings for similar incidents
- **Failed Approach Warnings**: Unsuccessful fixes get flagged as risky
- **Context-Aware Detection**: Command context improves future incident recognition
- **Continuous Improvement**: Each outcome refines troubleshooting accuracy

### Privacy and Control

- **Optional Participation**: Always choose whether to record outcomes
- **Lightweight Process**: Quick skip with no side effects
- **Manual Override**: Use `debug-outcome` anytime for manual recording
- **Local Storage**: All outcome data stored locally in SQLite database

## Testing

Run the test suite:
```bash
PYTHONPATH=src python3 -m pytest tests/
```

## Privacy

- All data stored locally in SQLite database
- No external data transmission required
- Learning signals and persona updates are traceable and reversible
- Full control over data retention and deletion
- Assessment responses and persona traits stored locally

## Development

See `docs/` for detailed documentation on architecture, memory models, and development guidelines.

## Testing

```bash
# Run tests
python -m pytest tests/

# Run specific intake tests
python -m pytest tests/test_intake.py
```

## License

MIT License - see LICENSE file for details.
