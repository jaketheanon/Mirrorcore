"""
Terminal Incident Signatures

Lightweight deterministic incident signature detection system.
"""

from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
import re


@dataclass
class IncidentSignature:
    """Represents a detected incident signature."""
    incident_type: str
    confidence: float
    matched_terms: List[str]
    likely_causes: List[str]
    recommended_first_checks: List[str]
    low_risk_initial_actions: List[str]


class IncidentSignatureDetector:
    """Detects common terminal incident patterns using deterministic rules."""
    
    def __init__(self):
        self.signatures = self._create_incident_signatures()
    
    def _create_incident_signatures(self) -> Dict[str, Dict[str, Any]]:
        """Create incident signature patterns."""
        return {
            # pip permission issues
            "pip_permission_denied": {
                "keywords": ["pip", "install", "permission", "denied", "error", "failed"],
                "phrases": ["permission denied", "error: could not create", "unable to create", "can't create"],
                "patterns": [
                    r"pip\s+install.*permission\s+denied",
                    r"pip\s+install.*error.*permission",
                    r"permission\s+denied.*pip"
                ],
                "confidence": 0.9,
                "likely_causes": [
                    "System-wide pip installation without sudo",
                    "Site-packages directory permissions",
                    "Virtual environment not activated",
                    "User pip installation conflicts"
                ],
                "recommended_first_checks": [
                    "Check if virtual environment is active: `echo $VIRTUAL_ENV`",
                    "Verify pip installation location: `which pip`",
                    "Check site-packages permissions: `ls -la $(python -m site --user-site)`"
                ],
                "low_risk_initial_actions": [
                    "Try user installation: `pip install --user package_name`",
                    "Create/activate virtual environment: `python -m venv venv && source venv/bin/activate`",
                    "Check if package already installed system-wide"
                ]
            },
            
            # docker container issues
            "docker_container_restart": {
                "keywords": ["docker", "container", "restart", "dies", "stops", "crash", "exit", "keep", "keeps", "automatically", "running", "stay", "loop", "won't", "restarting", "dying", "exiting"],
                "phrases": [
                    "container restart", "container dies", "container stops", "randomly restart", "keeps restarting", "automatically restarts", "container keeps dying", "container won't stay running", "won't stay running", "keep restarting", "container keeps dying", "container won't stay running", "keep dying", "restart loop", "infinite loop", "keeps exiting", "exiting", "docker container keeps restarting", "docker container dies and restarts automatically", "docker container randomly dies", "container dies and restarts automatically", "container won't stay running", "container keeps restarting", "container keeps dying", "container keeps exiting", "container is exiting", "container is restarting", "container is dying", "container is stopping", "container stopped working", "container crashes", "container failed", "container error", "docker container failure", "docker container problem", "docker container issue", "docker container trouble", "docker container won't start", "docker container can't start", "docker container not starting", "docker container broken"
                ],
                "patterns": [
                    r"docker\s+container.*restart",
                    r"container.*dies",
                    r"container.*stops.*randomly",
                    r"container.*keeps.*restart",
                    r"container.*automatically.*restart",
                    r"container.*won't.*stay.*running",
                    r"container.*keep.*restart",
                    r"container.*keep.*dying",
                    r"container.*loop.*restart",
                    r"container.*infinite.*loop",
                    r"container.*keeps.*exiting",
                    r"container.*exiting.*repeatedly",
                    r"docker\s+container.*keeps.*restarting",
                    r"docker\s+container.*dies.*and.*restarts",
                    r"docker\s+container.*dies.*and.*restarts.*automatically",
                    r"docker\s+container.*won't.*stay.*running",
                    r"docker\s+container.*can't.*start",
                    r"docker\s+container.*is.*dying",
                    r"docker\s+container.*is.*stopping",
                    r"docker\s+container.*stopped.*working",
                    r"docker\s+container.*crashes",
                    r"docker\s+container.*failed",
                    r"docker\s+container.*error",
                    r"docker\s+container.*problem",
                    r"docker\s+container.*trouble",
                    r"docker\s+container.*issue",
                    r"docker\s+container.*won't.*start",
                    r"docker\s+container.*can't.*start",
                    r"docker\s+container.*not.*starting"
                ],
                "confidence": 0.85,
                "likely_causes": [
                    "Resource exhaustion (memory/CPU)",
                    "Application crash/exception",
                    "Health check failures",
                    "External dependency issues",
                    "Infinite loop in container",
                    "Configuration issues",
                    "Resource limits exceeded"
                ],
                "recommended_first_checks": [
                    "Check container logs: `docker logs container_name`",
                    "Monitor resource usage: `docker stats container_name`",
                    "Inspect container state: `docker inspect container_name`",
                    "Check for infinite loops: `docker logs --tail 100 container_name`",
                    "Verify resource limits: `docker inspect container_name | grep -i memory`",
                    "Review container configuration: `docker inspect container_name | grep -i restart`"
                ],
                "low_risk_initial_actions": [
                    "Check recent application changes or deployments",
                    "Verify external service connectivity",
                    "Review resource limits and requests",
                    "Check for stuck processes: `docker exec container_name ps aux`",
                    "Test with minimal resources: `docker run --rm container_name /bin/sh`"
                ]
            },
            
            # systemd/service failures
            "systemd_service_failed": {
                "keywords": ["systemd", "service", "failed", "start", "restart", "status", "inactive", "journalctl", "dependency", "systemctl", "fails", "start myservice", "myservice", "service won't start", "service can't start"],
                "phrases": ["failed to start", "service failed", "inactive (dead)", "cannot start", "won't start", "dependency errors", "journalctl shows", "systemctl status shows", "systemctl start fails", "service won't start", "start myservice fails", "myservice failed", "myservice won't start"],
                "patterns": [
                    r"service.*failed.*start",
                    r"systemctl.*failed",
                    r"service.*inactive.*dead",
                    r"journalctl.*dependency.*error",
                    r"systemctl.*status.*inactive",
                    r"service.*won't.*start",
                    r"systemctl.*start.*fails",
                    r"start.*myservice.*fails",
                    r"myservice.*failed",
                    r"myservice.*won't.*start"
                ],
                "confidence": 0.9,
                "likely_causes": [
                    "Configuration file errors",
                    "Port conflicts or binding issues",
                    "Missing dependencies",
                    "Service dependency order issues"
                ],
                "recommended_first_checks": [
                    "Check service status: `systemctl status service_name`",
                    "Review service logs: `journalctl -u service_name`",
                    "Check dependencies: `systemctl list-dependencies service_name`"
                ],
                "low_risk_initial_actions": [
                    "Check if required ports are available: `netstat -tlnp | grep port`",
                    "Verify configuration file permissions",
                    "Test configuration with validation tools"
                ]
            },
            
            # command not found
            "command_not_found": {
                "keywords": ["command", "not", "found", "not found", "bash", "shell"],
                "phrases": ["command not found", "not found", "no such file", "command: not found"],
                "patterns": [
                    r"command\s+not\s+found",
                    r"bash:.*not\s+found",
                    r".*:\s+command\s+not\s+found"
                ],
                "confidence": 0.95,
                "likely_causes": [
                    "Command not installed",
                    "PATH environment issue",
                    "Typo in command name",
                    "Wrong shell or environment"
                ],
                "recommended_first_checks": [
                    "Verify command exists: `which command_name`",
                    "Check PATH: `echo $PATH`",
                    "Search for command: `find /usr -name command_name 2>/dev/null`"
                ],
                "low_risk_initial_actions": [
                    "Check correct spelling and case",
                    "Try full path to command",
                    "Install missing package if identified"
                ]
            },
            
            # network connectivity issues
            "network_connectivity": {
                "keywords": ["network", "connection", "refused", "timeout", "dns", "resolve", "host"],
                "phrases": ["connection refused", "connection timed out", "name resolution failed", "dns"],
                "patterns": [
                    r"connection\s+refused",
                    r"connection\s+timed\s+out",
                    r"name\s+resolution\s+failed",
                    r"dns.*failed"
                ],
                "confidence": 0.85,
                "likely_causes": [
                    "Service not running on target host",
                    "Firewall blocking connection",
                    "DNS resolution problems",
                    "Network configuration issues"
                ],
                "recommended_first_checks": [
                    "Test basic connectivity: `ping host`",
                    "Check port availability: `telnet host port`",
                    "Verify DNS resolution: `nslookup host`"
                ],
                "low_risk_initial_actions": [
                    "Check local network interface: `ip addr show`",
                    "Verify firewall rules: `iptables -L`",
                    "Test alternative DNS servers"
                ]
            },
            
            # configuration/syntax errors
            "config_syntax_error": {
                "keywords": ["config", "syntax", "error", "parse", "invalid", "malformed"],
                "phrases": ["syntax error", "parse error", "invalid syntax", "malformed"],
                "patterns": [
                    r"syntax\s+error",
                    r"parse\s+error",
                    r"invalid\s+syntax",
                    r"malformed.*config"
                ],
                "confidence": 0.9,
                "likely_causes": [
                    "Typo in configuration file",
                    "Wrong format or version",
                    "Missing required sections",
                    "Incorrect quoting or escaping"
                ],
                "recommended_first_checks": [
                    "Validate config syntax: `config_validator file`",
                    "Check file encoding and line endings",
                    "Review recent changes to configuration"
                ],
                "low_risk_initial_actions": [
                    "Backup current config and restore known-good version",
                    "Use configuration validation tools",
                    "Check documentation for correct format"
                ]
            },
            
            # git authentication/remote issues
            "git_auth_remote": {
                "keywords": ["git", "push", "pull", "clone", "auth", "authentication", "remote", "origin"],
                "phrases": ["authentication failed", "permission denied", "remote rejected", "git push"],
                "patterns": [
                    r"git.*push.*denied",
                    r"authentication.*failed",
                    r"remote.*rejected",
                    r"permission.*denied.*git"
                ],
                "confidence": 0.85,
                "likely_causes": [
                    "Incorrect credentials or token",
                    "SSH key not configured",
                    "Repository permissions",
                    "Network/firewall issues"
                ],
                "recommended_first_checks": [
                    "Test git authentication: `git config --list | grep user`",
                    "Check remote URL: `git remote -v`",
                    "Test SSH connection: `ssh -T git@github.com`"
                ],
                "low_risk_initial_actions": [
                    "Verify git credentials are current",
                    "Check SSH key configuration",
                    "Test with HTTPS alternative if SSH fails"
                ]
            }
        }
    
    def detect_incident(self, user_input: str, command_context: Optional[Dict[str, Any]] = None) -> Optional[IncidentSignature]:
        """Detect incident signature from user input with optional command context."""
        user_input_lower = user_input.lower()
        
        for incident_type, signature_config in self.signatures.items():
            # Check basic keyword/phrases/patterns matching
            keyword_matches = self._check_keywords(user_input_lower, signature_config.get('keywords', []))
            phrase_matches = self._check_phrases(user_input_lower, signature_config.get('phrases', []))
            pattern_matches = self._check_patterns(user_input, signature_config.get('patterns', []))
            
            # Calculate base confidence
            total_matches = len(keyword_matches) + len(phrase_matches) + len(pattern_matches)
            if total_matches == 0:
                continue
            
            base_confidence = signature_config.get('confidence', 0.5)
            
            # Apply command context boost if available
            context_boost = self._calculate_context_boost(incident_type, command_context)
            final_confidence = min(0.95, base_confidence + context_boost)  # Cap at 0.95
            
            # Only return if confidence meets threshold
            if final_confidence >= 0.7:
                matched_terms = keyword_matches + phrase_matches + pattern_matches
                
                return IncidentSignature(
                    incident_type=incident_type,
                    confidence=final_confidence,
                    matched_terms=matched_terms,
                    likely_causes=signature_config.get('likely_causes', []),
                    recommended_first_checks=signature_config.get('recommended_first_checks', []),
                    low_risk_initial_actions=signature_config.get('low_risk_initial_actions', [])
                )
        
        return None
    
    def _check_keywords(self, user_input: str, keywords: List[str]) -> List[str]:
        """Check for keyword matches."""
        matches = []
        for keyword in keywords:
            if keyword in user_input:
                matches.append(keyword)
        return matches
    
    def _check_phrases(self, user_input: str, phrases: List[str]) -> List[str]:
        """Check for phrase matches."""
        matches = []
        for phrase in phrases:
            if phrase in user_input:
                matches.append(phrase)
        return matches
    
    def _check_patterns(self, user_input: str, patterns: List[str]) -> List[str]:
        """Check for regex pattern matches."""
        matches = []
        for pattern in patterns:
            if re.search(pattern, user_input, re.IGNORECASE):
                matches.append(pattern)
        return matches
    
    def _calculate_context_boost(self, incident_type: str, command_context: Optional[Dict[str, Any]]) -> float:
        """Calculate confidence boost based on command context."""
        if not command_context:
            return 0.0
        
        subsystem = command_context.get('subsystem')
        if not subsystem:
            return 0.0
        
        # Define context boosts for specific incident type + subsystem combinations
        context_boosts = {
            # pip + permission_denied -> pip_permission_denied
            ('pip_permission_denied', 'pip'): 0.15,
            ('pip_permission_denied', 'python'): 0.10,
            
            # docker + container issues
            ('docker_container_restart', 'docker'): 0.15,
            ('docker_permission_denied', 'docker'): 0.15,
            ('docker_command_not_found', 'docker'): 0.10,
            
            # systemctl + service issues
            ('systemd_service_failed', 'systemctl'): 0.15,
            ('systemd_service_failed', 'journalctl'): 0.10,
            ('systemd_permission_denied', 'systemctl'): 0.15,
            
            # git + auth issues
            ('git_auth_remote', 'git'): 0.15,
            ('git_permission_denied', 'git'): 0.10,
            ('git_command_not_found', 'git'): 0.10,
            
            # npm/node + command issues
            ('npm_permission_denied', 'npm'): 0.15,
            ('npm_permission_denied', 'node'): 0.10,
            ('npm_command_not_found', 'npm'): 0.10,
            ('npm_command_not_found', 'node'): 0.10,
            
            # chmod/chown + permission issues
            ('permission_denied', 'chmod'): 0.15,
            ('permission_denied', 'chown'): 0.15,
            ('permission_denied', 'sudo'): 0.10,
            
            # curl/wget + network issues
            ('network_connectivity', 'curl'): 0.10,
            ('network_connectivity', 'wget'): 0.10,
            
            # ssh/scp + auth/network issues
            ('git_auth_remote', 'ssh'): 0.10,
            ('network_connectivity', 'ssh'): 0.10,
            ('network_connectivity', 'scp'): 0.10,
            
            # General command not found
            ('command_not_found', 'pip'): 0.10,
            ('command_not_found', 'docker'): 0.10,
            ('command_not_found', 'git'): 0.10,
            ('command_not_found', 'npm'): 0.10,
            ('command_not_found', 'node'): 0.10,
            ('command_not_found', 'python'): 0.10,
            ('command_not_found', 'systemctl'): 0.10,
            ('command_not_found', 'journalctl'): 0.10,
        }
        
        return context_boosts.get((incident_type, subsystem), 0.0)
