"""
Reasoning Response Engine

Lightweight first-pass reasoning response generator for Mirrorcore.
"""

from typing import Dict, Any, List, Optional
from dataclasses import dataclass
import re


@dataclass
class MessageCategory:
    """Message classification categories."""
    TROUBLESHOOTING = "troubleshooting"
    DECISION_SUPPORT = "decision_support"
    GENERAL_REASONING = "general_reasoning"
    UNKNOWN = "unknown"


@dataclass
class ResponseContext:
    """Context for generating responses."""
    user_input: str
    persona_profile: Dict[str, Any]
    conversation_history: List[Dict[str, Any]]
    memory_store: Optional[Any] = None
    db_store: Optional[Any] = None
    session_id: Optional[str] = None
    incident_id: Optional[str] = None  # For linking outcomes
    suggested_fixes: List[str] = None  # For outcome capture


@dataclass
class ResponseResult:
    """Result of response generation with optional outcome capture."""
    response: str
    should_prompt_outcome: bool = False
    incident_id: Optional[str] = None
    suggested_fixes: List[str] = None
    


class ReasoningResponseEngine:
    """Lightweight reasoning response engine for Mirrorcore."""
    
    def __init__(self):
        # Simple keyword patterns for classification
        self.troubleshooting_keywords = [
            # Original keywords
            "error", "broken", "failed", "crash", "bug", "issue", "problem",
            "not working", "fix", "debug", "wont", "can't", "unable", "stuck",
            "command", "terminal", "bash", "python", "install", "setup", "configure",
            
            # Infrastructure / systems terms
            "docker", "container", "service", "daemon", "systemd", "process", 
            "thread", "cluster", "node", "server", "pod", "namespace", "kubernetes",
            "vm", "virtual machine", "instance", "microservice", "application",
            
            # Failure indicators
            "dies", "die", "restart", "restarts", "fails", "failure", "hang", 
            "hangs", "freeze", "freezes", "timeout", "timeouts", "stops", "stopped",
            "killed", "terminate", "terminated", "crash", "crashes", "crashed",
            "down", "offline", "unavailable", "dead", "zombie",
            
            # Diagnostics language
            "logs", "logging", "log", "debug", "trace", "stacktrace", "stack trace",
            "investigate", "diagnose", "diagnostic", "root cause", "troubleshoot",
            "monitor", "monitoring", "metrics", "profiling", "analyze", "check",
            "verify", "test", "testing", "inspect", "examine",
            
            # Resource indicators
            "cpu", "memory", "ram", "disk", "disk space", "network", "latency",
            "bandwidth", "throughput", "load", "performance", "resource", "usage",
            "quota", "limit", "threshold", "capacity", "utilization",
            
            # Common troubleshooting patterns
            "slow", "slower", "unresponsive", "stuck", "hanging", "leaking",
            "overflow", "exhausted", "depleted", "congested", "bottleneck"
        ]
        
        # Troubleshooting question patterns
        self.troubleshooting_patterns = [
            "what would you investigate",
            "how would you debug",
            "why is this happening",
            "what's wrong with",
            "why won't",
            "why can't",
            "how do i fix",
            "what's causing",
            "why does",
            "how to troubleshoot",
            "help me debug",
            "help me fix"
        ]
        
        # Initialize incident signature detector
        try:
            from ..terminal.signatures import IncidentSignatureDetector
            self.incident_detector = IncidentSignatureDetector()
        except ImportError:
            self.incident_detector = None
        
        self.decision_keywords = [
            "decide", "choice", "option", "which", "better", "should i", "recommend",
            "advice", "help me decide", "tradeoff", "pros and cons", "compare",
            "choose", "select", "pick", "go with", "prefer"
        ]
        
        self.reasoning_keywords = [
            "why", "how", "what if", "think", "believe", "consider", "analyze",
            "understand", "explain", "reason", "logic", "approach", "strategy",
            "plan", "method", "way to", "best practice", "opinion", "view"
        ]
    
    def classify_message(self, user_input: str) -> MessageCategory:
        """Classify user message into category."""
        user_input_lower = user_input.lower()
        
        # Check for troubleshooting indicators (keywords + patterns)
        if (any(keyword in user_input_lower for keyword in self.troubleshooting_keywords) or
            any(pattern in user_input_lower for pattern in self.troubleshooting_patterns)):
            return MessageCategory.TROUBLESHOOTING
        
        # Check for decision support indicators
        if any(keyword in user_input_lower for keyword in self.decision_keywords):
            return MessageCategory.DECISION_SUPPORT
        
        # Check for reasoning indicators
        if any(keyword in user_input_lower for keyword in self.reasoning_keywords):
            return MessageCategory.GENERAL_REASONING
        
        return MessageCategory.UNKNOWN
    
    def generate_troubleshooting_response(self, context: ResponseContext) -> ResponseResult:
        """Generate troubleshooting response with outcome capture support."""
        user_input = context.user_input
        
        # First try incident signature detection
        if self.incident_detector:
            incident = self.incident_detector.detect_incident(user_input)
            if incident:
                return self._generate_targeted_response(incident, context)
        
        # Fallback to general troubleshooting
        response = self._generate_general_troubleshooting_response(user_input, context)
        return ResponseResult(response=response, should_prompt_outcome=False)
    
    def _generate_targeted_response(self, incident, context: ResponseContext) -> ResponseResult:
        """Generate targeted response for detected incident."""
        incident_type = incident.incident_type.replace('_', ' ').title()
        
        response = f"I recognize this as a {incident_type} issue. Let me provide targeted guidance:\n\n"
        
        # Add likely causes
        if incident.likely_causes:
            response += "Most likely causes:\n"
            for i, cause in enumerate(incident.likely_causes[:3], 1):  # Show top 3
                response += f"{i}. {cause}\n"
            response += "\n"
        
        # Add recommended first checks
        if incident.recommended_first_checks:
            response += "First checks to run:\n"
            for i, check in enumerate(incident.recommended_first_checks[:4], 1):  # Show top 4
                response += f"{i}. {check}\n"
            response += "\n"
        
        # Add low-risk initial actions
        if incident.low_risk_initial_actions:
            response += "Low-risk initial actions:\n"
            for i, action in enumerate(incident.low_risk_initial_actions[:3], 1):  # Show top 3
                response += f"• {action}\n"
            response += "\n"
        
        # Add historical context if available
        suggested_fixes = []
        if hasattr(context, 'memory_store') and context.memory_store:
            try:
                # Get ranked fixes for this incident type
                ranked_fixes = context.memory_store.get_ranked_fixes_by_incident_type(
                    incident.incident_type, limit=3
                )
                
                if ranked_fixes:
                    response += "Based on previous outcomes for this issue:\n"
                    
                    # Show top ranked fix with explanation
                    top_fix = ranked_fixes[0]
                    response += f"Most successful approach: {top_fix['normalized_fix']}\n"
                    response += f"  Reason: {top_fix['success_count']} successful, {top_fix['failed_count']} failed attempts\n"
                    
                    # Collect suggested fixes for outcome capture
                    suggested_fixes.append(top_fix['normalized_fix'])
                    
                    # Show other successful options
                    successful_fixes = [f for f in ranked_fixes if f['success_count'] > 0]
                    if len(successful_fixes) > 1:
                        response += "Other successful approaches:\n"
                        for i, fix in enumerate(successful_fixes[1:3], 2):  # Show next 2
                            response += f"  {i}. {fix['normalized_fix']} ({fix['success_count']} success)\n"
                            suggested_fixes.append(fix['normalized_fix'])
                    
                    # Warn about commonly failed approaches
                    failed_fixes = [f for f in ranked_fixes if f['failed_count'] > f['success_count']]
                    if failed_fixes:
                        response += "Approaches that typically fail:\n"
                        for fix in failed_fixes[:2]:  # Show top 2 failed
                            response += f"  • {fix['normalized_fix']} ({fix['failed_count']} failed)\n"
                    
                    response += "\n"
                    
            except Exception:
                # Don't fail if memory retrieval fails
                pass
        
        # Add recommended fixes to suggested fixes if available
        if incident.recommended_first_checks:
            for check in incident.recommended_first_checks[:2]:  # Add top 2 checks
                if check not in suggested_fixes:
                    suggested_fixes.append(check)
        
        response += "These steps should help identify the root cause. Let me know what you discover!"
        
        # Apply persona style
        styled_response = self._apply_persona_style(response, context, "troubleshooting")
        
        # Return result with outcome capture support
        return ResponseResult(
            response=styled_response,
            should_prompt_outcome=True,  # Enable outcome capture for targeted responses
            incident_id=getattr(context, 'incident_id', None),
            suggested_fixes=suggested_fixes
        )
    
    def _generate_general_troubleshooting_response(self, user_input: str, context: ResponseContext) -> str:
        """Generate general troubleshooting response when no signature matches."""
        user_input_lower = user_input.lower()
        
        # Identify likely issue type
        if any(word in user_input_lower for word in ["error", "failed", "crash", "broken"]):
            response = "I can help troubleshoot that. Let's approach this systematically:\n\n"
            response += "1. What exactly happened or what error message did you see?\n"
            response += "2. What were you trying to do when it occurred?\n"
            response += "3. Have you tried any basic fixes (restart, check permissions, verify syntax)?\n\n"
            response += "Once you provide these details, I can help identify the root cause and suggest specific steps."
            
        elif any(word in user_input_lower for word in ["command", "bash", "terminal"]):
            response = "For command-line issues, let's break this down:\n\n"
            response += "1. What command are you trying to run?\n"
            response += "2. What's the exact error or unexpected output?\n"
            response += "3. Can you show me the full command and any relevant context?\n\n"
            response += "I'll help you debug the command structure or identify the issue."
            
        elif any(word in user_input for word in ["docker", "container", "service", "daemon", "server"]):
            response = "For container/service issues, let's investigate systematically:\n\n"
            response += "1. What specific behavior are you seeing (crashes, restarts, hangs)?\n"
            response += "2. What do the logs show when this happens?\n"
            response += "3. Are there resource constraints (CPU, memory, disk space)?\n"
            response += "4. Has anything changed recently (updates, config changes)?\n\n"
            response += "This will help identify whether it's a resource issue, configuration problem, or external dependency."
            
        elif any(word in user_input for word in ["cpu", "memory", "performance", "load"]):
            response = "For performance/resource issues, let's analyze this methodically:\n\n"
            response += "1. What are the current resource metrics (CPU %, memory usage, load average)?\n"
            response += "2. When did the performance issue start and what triggers it?\n"
            response += "3. Are there specific processes or operations consuming resources?\n"
            response += "4. Have you checked for memory leaks, infinite loops, or resource exhaustion?\n\n"
            response += "This will help distinguish between normal load and actual performance problems."
            
        elif any(word in user_input for word in ["logs", "debug", "investigate", "diagnose"]):
            response = "For debugging and investigation, let's establish a systematic approach:\n\n"
            response += "1. What specific problem are you trying to diagnose?\n"
            response += "2. What logging or monitoring tools are available?\n"
            response += "3. What have you already checked and what were the findings?\n"
            response += "4. Can you reproduce the issue or is it intermittent?\n\n"
            response += "I'll help you build a structured investigation plan to identify the root cause."
            
        else:
            response = "I understand you're dealing with a technical issue. "
            response += "To help you effectively:\n\n"
            response += "• Describe the specific problem or error\n"
            response += "• Share any relevant error messages\n"
            response += "• Let me know what you've already tried\n\n"
            response += "This will help me provide targeted assistance rather than general suggestions."
        
        return self._apply_persona_style(response, context, "troubleshooting")
    
    def prompt_assisted_outcome_capture(self, incident_id: str, suggested_fixes: List[str]) -> str:
        """Generate prompt for assisted outcome capture."""
        prompt = "\n" + "=" * 60 + "\n"
        prompt += "🎯 OUTCOME CAPTURE\n"
        prompt += "=" * 60 + "\n"
        prompt += "Did one of these suggested fixes solve the issue? [y/N]\n"
        
        if suggested_fixes:
            prompt += "\nSuggested fixes from this session:\n"
            for i, fix in enumerate(suggested_fixes[:5], 1):  # Show top 5
                prompt += f"  {i}. {fix}\n"
        
        prompt += "\nIf you'd like to record the outcome now, type 'y' and I'll collect:\n"
        prompt += "  • Which fix you attempted\n"
        prompt += "  • Result (success/failed/partial/unknown)\n"
        prompt += "  • Confirmed root cause (optional)\n"
        prompt += "  • Additional notes (optional)\n"
        prompt += "\nYou can also use 'mirrorcore debug-outcome' anytime to record outcomes.\n"
        
        return prompt
    
    def generate_decision_support_response(self, context: ResponseContext) -> str:
        """Generate decision support response."""
        response = "I can help you think through this decision. "
        
        # Extract key elements
        user_input = context.user_input.lower()
        
        # Look for decision elements
        if "or" in user_input and any(word in user_input for word in ["choose", "select", "pick"]):
            response += "I see you're choosing between options. "
            response += "Let me help you evaluate the tradeoffs.\n\n"
            response += "What are the key factors you're considering? (cost, time, risk, quality, etc.)\n"
            response += "What are the main pros and cons of each option?\n"
            response += "Is there a time constraint or deadline?\n\n"
            response += "Once I understand these details, I can help you structure this decision."
            
        elif any(word in user_input for word in ["better", "prefer", "recommend"]):
            response += "I can help analyze that recommendation. "
            response += "Let's consider:\n\n"
            response += "• What evidence supports this recommendation?\n"
            response += "• What are the potential downsides or risks?\n"
            response += "• Does this align with your past experiences or goals?\n\n"
            response += "This will help us evaluate whether it's the right choice for you."
            
        else:
            response += "Let me help you work through this decision systematically. "
            response += "I'll ask some clarifying questions to understand the full context:\n\n"
            response += "1. What's the main objective you're trying to achieve?\n"
            response += "2. What are the available options or approaches?\n"
            response += "3. What constraints or considerations are most important?\n\n"
            response += "This framework will help us make a more informed choice."
        
        return self._apply_persona_style(response, context, "decision_support")
    
    def generate_general_reasoning_response(self, context: ResponseContext) -> str:
        """Generate general reasoning response."""
        user_input = context.user_input.lower()
        
        # Look for reasoning patterns
        if any(word in user_input for word in ["why", "how"]):
            response = "That's a good question. "
            
            if "why" in user_input:
                response += "Understanding the 'why' helps us address root causes rather than symptoms. "
                response += "What specific situation or outcome are you trying to understand?"
            else:  # "how"
                response += "Knowing 'how' helps with implementation and process. "
                response += "What process or approach are you trying to figure out?"
            
            response += "\n\nBreaking this down systematically will lead to better insights."
            
        elif any(word in user_input for word in ["think", "believe", "consider"]):
            response = "I appreciate you sharing your thinking process. "
            response += "Exploring different angles helps strengthen our reasoning. "
            response += "What alternative perspectives or counter-arguments should we consider?"
            response += "What evidence would strengthen or challenge this view?"
            
        elif any(word in user_input for word in ["understand", "explain"]):
            response = "Let me help clarify this concept. "
            response += "What specific aspect is most important to understand first?"
            response += "Are there any particular examples or contexts that would make this clearer?"
            
        else:
            response = "That's an interesting perspective. "
            response += "Let me explore this with you:\n\n"
            response += "• What's the core question or issue here?\n"
            response += "• What assumptions are we working with?\n"
            response += "• What would be the most useful way to move forward?\n\n"
            response += "This will help us develop a more complete understanding."
        
        return self._apply_persona_style(response, context, "general_reasoning")
    
    def generate_unknown_response(self, context: ResponseContext) -> str:
        """Generate response for unknown message types."""
        response = "I'm here to help and learn from our conversation. "
        response += "Could you tell me more about what you're working on or what you'd like assistance with?\n\n"
        response += "I can help with:\n"
        response += "• Technical troubleshooting and debugging\n"
        response += "• Decision analysis and tradeoff evaluation\n"
        response += "• General reasoning and problem-solving\n"
        response += "• Learning from patterns and preferences\n\n"
        response += "What would be most helpful for you right now?"
        
        return self._apply_persona_style(response, context, "unknown")
    
    def _apply_persona_style(self, response: str, context: ResponseContext, response_type: str) -> str:
        """Apply persona-aware styling to responses."""
        if not context.persona_profile:
            return response
        
        # Extract relevant persona traits
        traits = context.persona_profile
        
        # Helper function to safely get numeric trait values
        def get_trait_value(trait_name: str, default: float = 0.5) -> float:
            trait_data = traits.get(trait_name, {})
            if isinstance(trait_data, dict):
                value = trait_data.get('value', default)
                # Convert to float if it's a string or int
                try:
                    return float(value)
                except (ValueError, TypeError):
                    return default
            elif isinstance(trait_data, (int, float)):
                return float(trait_data)
            else:
                return default
        
        # Apply evidence_threshold styling
        evidence_threshold = get_trait_value('evidence_threshold', 0.5)
        if evidence_threshold > 0.7:  # High evidence preference
            if response_type in ["troubleshooting", "general_reasoning"]:
                response += "\n\nLet me suggest a systematic approach to verify this."
            elif response_type == "decision_support":
                response += "\n\nI recommend gathering data before committing to a decision."
        
        # Apply ambiguity_tolerance styling
        ambiguity_tolerance = get_trait_value('ambiguity_tolerance', 0.5)
        if ambiguity_tolerance < 0.3:  # Low ambiguity tolerance
            response = response.replace("uncertain", "unclear").replace("might be", "could be")
        elif ambiguity_tolerance > 0.7:  # High ambiguity tolerance
            if "options" in response:
                response += "\n\nThere are multiple valid approaches here."
        
        # Apply action_bias styling
        action_bias = get_trait_value('action_bias', 0.5)
        if action_bias > 0.7:  # High action bias
            if response_type == "troubleshooting":
                response += "\n\nLet's try a quick fix and iterate if needed."
            elif response_type == "decision_support":
                response += "\n\nWhat's a small step we could take to move forward?"
        elif action_bias < 0.3:  # Low action bias
            if response_type == "troubleshooting":
                response += "\n\nLet's analyze this thoroughly before taking action."
            elif response_type == "decision_support":
                response += "\n\nLet's make sure we understand all aspects first."
        
        # Apply self_reliance styling
        self_reliance = get_trait_value('self_reliance_level', 0.5)
        if self_reliance > 0.7:  # High self-reliance
            response += "\n\nI'll provide guidance, but you should trust your judgment too."
        elif self_reliance < 0.3:  # Low self-reliance
            response += "\n\nLet me work through this together step by step."
        
        return response
    
    def generate_response(self, user_input: str, persona_profile: Dict[str, Any], 
                      conversation_history: List[Dict[str, Any]], 
                      session_id: str = None, db_store=None) -> str:
        """Generate appropriate response based on user input and persona."""
        context = ResponseContext(
            user_input=user_input,
            persona_profile=persona_profile,
            conversation_history=conversation_history,
            memory_store=db_store  # Add memory store for outcome tracking
        )
        
        # Classify the message
        category = self.classify_message(user_input)
        
        # Generate response based on category
        if category == MessageCategory.TROUBLESHOOTING:
            # Check for incident signature
            if self.incident_detector and db_store:
                incident = self.incident_detector.detect_incident(user_input)
                if incident:
                    # Store the incident signature
                    try:
                        incident_id = db_store.save_incident_signature(user_input, incident, session_id)
                        context.incident_id = incident_id  # Add incident ID to context
                    except Exception:
                        # Don't fail if storage fails
                        pass
                    
                    # Generate targeted response
                    response_result = self._generate_targeted_response(incident, context)
                    return response_result
            
            # Fallback to general troubleshooting
            response = self._generate_general_troubleshooting_response(user_input, context)
            return ResponseResult(response=response, should_prompt_outcome=False)
        elif category == MessageCategory.DECISION_SUPPORT:
            response = self.generate_decision_support_response(context)
            return ResponseResult(response=response, should_prompt_outcome=False)
        elif category == MessageCategory.GENERAL_REASONING:
            response = self.generate_general_reasoning_response(context)
            return ResponseResult(response=response, should_prompt_outcome=False)
        else:
            response = self.generate_unknown_response(context)
            return ResponseResult(response=response, should_prompt_outcome=False)
