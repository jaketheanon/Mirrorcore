"""
Memory Retrieval

Retrieves relevant memories based on context and queries.
"""

from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import math


@dataclass
class RetrievalQuery:
    """Represents a memory retrieval query."""
    text: str
    context: Dict[str, Any]
    limit: int = 10
    min_relevance: float = 0.3
    time_window_days: Optional[int] = None


@dataclass
class RetrievedMemory:
    """Represents a retrieved memory with relevance score."""
    memory: Dict[str, Any]
    relevance_score: float
    retrieval_reason: str


class MemoryRetrieval:
    """Retrieves relevant memories based on context and queries."""
    
    def __init__(self):
        self.retrieval_strategies = {
            "text_similarity": self._text_similarity_search,
            "context_matching": self._context_matching_search,
            "temporal_proximity": self._temporal_proximity_search,
            "pattern_matching": self._pattern_matching_search
        }
    
    def search_memories(self, query: RetrievalQuery, memory_store) -> List[RetrievedMemory]:
        """Search memories using multiple strategies."""
        all_results = []
        
        # Apply different retrieval strategies
        for strategy_name, strategy_func in self.retrieval_strategies.items():
            results = strategy_func(query, memory_store)
            all_results.extend(results)
        
        # Deduplicate and rank results
        deduplicated_results = self._deduplicate_results(all_results)
        ranked_results = self._rank_results(deduplicated_results, query)
        
        # Filter by minimum relevance and limit
        filtered_results = [
            r for r in ranked_results 
            if r.relevance_score >= query.min_relevance
        ][:query.limit]
        
        return filtered_results
    
    def fetch_learning_signals(self, memory_store, signal_type: Optional[str] = None, 
                           session_id: Optional[str] = None,
                           days_back: int = 30) -> List[Dict[str, Any]]:
        """Fetch conversation learning signals for persona update evaluation."""
        # Create query for learning signals
        query = RetrievalQuery(
            text="",
            context={"memory_type": "learning_signal"},
            limit=100,
            time_window_days=days_back,
            min_relevance=0.1
        )
        
        # Get all learning signals
        all_signals = []
        memories = memory_store.search_memories("", limit=100)
        
        for memory in memories:
            content = memory.get("content", "")
            
            # Check if this is a learning signal
            if ("signal_type" in content and "session_id" in content and 
                memory.get("memory_type") == "learning_signal"):
                
                # Parse the content (should be JSON string)
                try:
                    import json
                    signal_data = json.loads(content) if isinstance(content, str) else content
                    
                    # Filter by signal type if specified
                    if signal_type and signal_data.get("signal_type") != signal_type:
                        continue
                    
                    # Filter by session ID if specified
                    if session_id and signal_data.get("session_id") != session_id:
                        continue
                    
                    all_signals.append(signal_data)
                except:
                    continue
        
        return all_signals
    
    def fetch_signals_by_trait(self, trait_name: str, memory_store, days_back: int = 30) -> List[Dict[str, Any]]:
        """Fetch learning signals for a specific trait."""
        # Map traits to signal types
        trait_to_signals = {
            "communication_preference": ["directness_preference", "communication_preference"],
            "evidence_threshold": ["evidence_preference"],
            "ambiguity_tolerance": ["ambiguity_tolerance"],
            "action_bias": ["action_bias"],
            "trust_verification_style": ["trust_verification_style"],
            "self_reliance_level": ["self_reliance_level"],
            "confidence_calibration": ["uncertainty_response"]
        }
        
        relevant_signal_types = trait_to_signals.get(trait_name, [])
        all_signals = []
        
        for signal_type in relevant_signal_types:
            signals = self.fetch_learning_signals(
                signal_type=signal_type,
                days_back=days_back,
                memory_store=memory_store
            )
            all_signals.extend(signals)
        
        return all_signals
    
    def summarize_signal_directions(self, signals: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Summarize signal directions across multiple signals."""
        if not signals:
            return {"positive": 0, "negative": 0, "neutral": 0, "total": 0}
        
        positive_count = sum(1 for s in signals if s.get("inferred_direction") == "positive")
        negative_count = sum(1 for s in signals if s.get("inferred_direction") == "negative")
        total_count = len(signals)
        
        return {
            "positive": positive_count,
            "negative": negative_count,
            "neutral": total_count - positive_count - negative_count,
            "total": total_count,
            "positive_ratio": positive_count / total_count if total_count > 0 else 0,
            "negative_ratio": negative_count / total_count if total_count > 0 else 0
        }
    
    def get_similar_situations(self, current_situation: Dict[str, Any], memory_store, limit: int = 5) -> List[RetrievedMemory]:
        """Get similar situations to current context."""
        query = RetrievalQuery(
            text=current_situation.get("description", ""),
            context=current_situation.get("context", {}),
            limit=limit
        )
        
        return self.search_memories(query, memory_store)
    
    def get_successful_solutions(self, problem_type: str, memory_store, limit: int = 10) -> List[RetrievedMemory]:
        """Get successful solutions for a specific problem type."""
        # Create query for successful solutions
        query = RetrievalQuery(
            text=problem_type,
            context={"outcome": "success", "problem_type": problem_type},
            limit=limit,
            min_relevance=0.5
        )
        
        return self.search_memories(query, memory_store)
    
    def _text_similarity_search(self, query: RetrievalQuery, memory_store) -> List[RetrievedMemory]:
        """Search based on text similarity."""
        results = []
        
        # Get all memories from store
        all_memories = memory_store.search_memories(query.text, limit=100)
        
        for memory in all_memories:
            # Calculate text similarity
            similarity = self._calculate_text_similarity(query.text, memory)
            
            if similarity > 0.3:  # Minimum similarity threshold
                result = RetrievedMemory(
                    memory=memory,
                    relevance_score=similarity * 0.8,  # Weight for text similarity
                    retrieval_reason="text_similarity"
                )
                results.append(result)
        
        return results
    
    def _context_matching_search(self, query: RetrievalQuery, memory_store) -> List[RetrievedMemory]:
        """Search based on context matching."""
        results = []
        
        # For now, use simple context matching
        # In a full implementation, this would query the database directly
        all_memories = memory_store.search_memories("", limit=100)  # Get all memories
        
        for memory in all_memories:
            context_score = self._calculate_context_similarity(query.context, memory.get("context", {}))
            
            if context_score > 0.3:
                result = RetrievedMemory(
                    memory=memory,
                    relevance_score=context_score * 0.7,  # Weight for context matching
                    retrieval_reason="context_matching"
                )
                results.append(result)
        
        return results
    
    def _temporal_proximity_search(self, query: RetrievalQuery, memory_store) -> List[RetrievedMemory]:
        """Search based on temporal proximity."""
        results = []
        
        if query.time_window_days:
            # Calculate time window
            cutoff_date = datetime.utcnow() - timedelta(days=query.time_window_days)
            
            # Get recent memories
            all_memories = memory_store.search_memories("", limit=100)
            
            for memory in all_memories:
                memory_time = datetime.fromisoformat(memory.get("timestamp", "").replace('Z', '+00:00'))
                
                if memory_time >= cutoff_date:
                    # Calculate recency score
                    days_old = (datetime.utcnow() - memory_time).days
                    recency_score = max(0, 1 - (days_old / query.time_window_days))
                    
                    result = RetrievedMemory(
                        memory=memory,
                        relevance_score=recency_score * 0.3,  # Weight for recency
                        retrieval_reason="temporal_proximity"
                    )
                    results.append(result)
        
        return results
    
    def _pattern_matching_search(self, query: RetrievalQuery, memory_store) -> List[RetrievedMemory]:
        """Search based on pattern matching."""
        results = []
        
        # Look for patterns in the query
        patterns = self._extract_patterns(query.text)
        
        if patterns:
            all_memories = memory_store.search_memories("", limit=100)
            
            for memory in all_memories:
                pattern_score = self._calculate_pattern_match(patterns, memory)
                
                if pattern_score > 0.4:
                    result = RetrievedMemory(
                        memory=memory,
                        relevance_score=pattern_score * 0.6,  # Weight for pattern matching
                        retrieval_reason="pattern_matching"
                    )
                    results.append(result)
        
        return results
    
    def _calculate_text_similarity(self, text1: str, memory: Dict[str, Any]) -> float:
        """Calculate text similarity between query and memory."""
        # Simple word overlap similarity
        # In a full implementation, this would use embeddings or more sophisticated NLP
        
        content_text = memory.get("content", {}).get("input", "") + " " + memory.get("content", {}).get("output", "")
        
        words1 = set(text1.lower().split())
        words2 = set(content_text.lower().split())
        
        if not words1 or not words2:
            return 0.0
        
        intersection = words1.intersection(words2)
        union = words1.union(words2)
        
        return len(intersection) / len(union)
    
    def _calculate_context_similarity(self, context1: Dict[str, Any], context2: Dict[str, Any]) -> float:
        """Calculate context similarity."""
        if not context1 or not context2:
            return 0.0
        
        # Simple field matching
        matching_fields = 0
        total_fields = 0
        
        for key in context1:
            if key in context2:
                total_fields += 1
                if context1[key] == context2[key]:
                    matching_fields += 1
        
        if total_fields == 0:
            return 0.0
        
        return matching_fields / total_fields
    
    def _extract_patterns(self, text: str) -> List[str]:
        """Extract patterns from query text."""
        patterns = []
        
        # Common error patterns
        error_patterns = ["error", "failed", "denied", "timeout", "refused"]
        for pattern in error_patterns:
            if pattern in text.lower():
                patterns.append(f"error_{pattern}")
        
        # Command patterns
        if any(cmd in text.lower() for cmd in ["git", "docker", "npm", "pip"]):
            patterns.append("command_related")
        
        return patterns
    
    def _calculate_pattern_match(self, patterns: List[str], memory: Dict[str, Any]) -> float:
        """Calculate pattern match score."""
        memory_text = (memory.get("content", {}).get("input", "") + " " + 
                      memory.get("content", {}).get("output", "")).lower()
        
        matches = 0
        for pattern in patterns:
            if pattern.replace("_", " ") in memory_text:
                matches += 1
        
        return matches / len(patterns) if patterns else 0.0
    
    def _deduplicate_results(self, results: List[RetrievedMemory]) -> List[RetrievedMemory]:
        """Remove duplicate results."""
        seen_ids = set()
        deduplicated = []
        
        for result in results:
            memory_id = result.memory.get("id")
            if memory_id and memory_id not in seen_ids:
                seen_ids.add(memory_id)
                deduplicated.append(result)
        
        return deduplicated
    
    def _rank_results(self, results: List[RetrievedMemory], query: RetrievalQuery) -> List[RetrievedMemory]:
        """Rank results by relevance score."""
        # Sort by relevance score (descending)
        return sorted(results, key=lambda r: r.relevance_score, reverse=True)
