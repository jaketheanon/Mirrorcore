#!/usr/bin/env python3
"""
Mirrorcore Main Entry Point

This module provides the main CLI interface for Mirrorcore.
"""

import sys
import argparse
from pathlib import Path

from .config import get_config
from .db.store import DatabaseStore
from .intake.scenario_engine import ScenarioEngine
from .intake.profiler import Profiler

__version__ = "0.1.0"
__description__ = "A local-first reasoning assistant for personalized troubleshooting and decision support"


def create_parser():
    """Create the main argument parser."""
    parser = argparse.ArgumentParser(
        prog="mirrorcore",
        description=__description__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  mirrorcore                                    # Start interactive session
  mirrorcore debug "git push failed"            # Debug a command
  mirrorcore decide "use PostgreSQL or SQLite" # Get decision help
  mirrorcore profile                            # View your profile
        """
    )
    
    # Global options
    parser.add_argument(
        "--version",
        action="version",
        version=f"Mirrorcore {__version__}"
    )
    
    parser.add_argument(
        "--config",
        type=str,
        help="Path to configuration file"
    )
    
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose output"
    )
    
    parser.add_argument(
        "--quiet",
        action="store_true", 
        help="Suppress non-error output"
    )
    
    # Subcommands
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Interactive mode (default)
    interactive_parser = subparsers.add_parser(
        "interactive",
        help="Start interactive session"
    )
    
    # Debug command
    debug_parser = subparsers.add_parser(
        "debug",
        help="Debug terminal issues"
    )
    debug_parser.add_argument(
        "problem",
        help="Problem description or command that failed"
    )
    debug_parser.add_argument(
        "--stdin",
        action="store_true",
        help="Read problem from stdin"
    )
    
    # Decide command
    decide_parser = subparsers.add_parser(
        "decide",
        help="Get decision assistance"
    )
    decide_parser.add_argument(
        "decision",
        help="Decision context or question"
    )
    
    # Profile command
    profile_parser = subparsers.add_parser(
        "profile",
        help="Manage persona profile"
    )
    profile_parser.add_argument(
        "--analyze",
        action="store_true",
        help="Analyze recent patterns"
    )
    profile_parser.add_argument(
        "--update",
        help="Update specific profile aspect"
    )
    
    # Assessment command
    assess_parser = subparsers.add_parser(
        "assess",
        help="Run initial assessment"
    )
    assess_parser.add_argument(
        "--continue",
        action="store_true",
        help="Continue previous assessment"
    )
    
    # Init command
    init_parser = subparsers.add_parser(
        "init",
        help="Initialize persona assessment"
    )
    
    # Memory command
    memory_parser = subparsers.add_parser(
        "memory",
        help="Memory management"
    )
    memory_parser.add_argument(
        "action",
        choices=["search", "stats", "export", "import"],
        help="Memory action"
    )
    
    # Status command
    status_parser = subparsers.add_parser(
        "status",
        help="Show system status"
    )
    
    # Config command
    config_parser = subparsers.add_parser(
        "config",
        help="Configuration management"
    )
    config_parser.add_argument(
        "--get",
        help="Get configuration value"
    )
    config_parser.add_argument(
        "--set",
        nargs=2,
        metavar=("KEY", "VALUE"),
        help="Set configuration value"
    )
    
    return parser


def handle_interactive(args):
    """Handle interactive mode with learning pipeline."""
    from pathlib import Path
    from .db.store import DatabaseStore
    from .memory.extractor import MemoryExtractor
    from .memory.updater import MemoryUpdater
    from .memory.retrieval import MemoryRetrieval
    import uuid
    import json
    from datetime import datetime
    
    print("Starting interactive Mirrorcore session...")
    print("Type 'help' for available commands or 'exit' to quit")
    
    # Initialize components
    db_path = Path("data") / "mirrorcore.db"
    db_store = DatabaseStore(db_path)
    extractor = MemoryExtractor()
    updater = MemoryUpdater()
    retrieval = MemoryRetrieval()
    
    # Generate session ID
    session_id = str(uuid.uuid4())
    conversation = []
    
    print(f"\nSession ID: {session_id[:8]}...")
    print("Mirrorcore will learn from your conversation patterns.")
    print("Type 'exit' to end session.\n")
    
    try:
        while True:
            # Get user input
            try:
                user_input = input("You: ").strip()
            except EOFError:
                break
            
            if user_input.lower() in ['exit', 'quit']:
                break
            
            if user_input.lower() == 'help':
                print("Available commands:")
                print("  help  - Show this help")
                print("  exit  - End session")
                print("  status - Show learning status")
                print("\nJust chat normally - Mirrorcore learns from patterns!")
                continue
            
            if user_input.lower() == 'status':
                # Show learning status
                signals = retrieval.fetch_learning_signals(session_id=session_id, memory_store=db_store)
                print(f"\nLearning signals captured: {len(signals)}")
                
                if signals:
                    # Show signal types detected
                    signal_types = {}
                    for signal in signals:
                        stype = signal.get('signal_type', 'unknown')
                        signal_types[stype] = signal_types.get(stype, 0) + 1
                    
                    print("Signal types detected:")
                    for stype, count in signal_types.items():
                        print(f"  {stype}: {count}")
                print()
                continue
            
            # Add user message to conversation
            conversation.append({
                "role": "user",
                "content": user_input,
                "timestamp": datetime.utcnow().isoformat()
            })
            
            # Simple response (placeholder)
            if "hello" in user_input.lower() or "hi" in user_input.lower():
                response = "Hello! I'm here to help and learn from our conversation."
            elif "how are you" in user_input.lower():
                response = "I'm doing well, thanks! I'm learning from our interaction patterns."
            elif "learn" in user_input.lower():
                response = "Yes, I extract patterns from our conversations to better understand your preferences over time."
            else:
                response = f"I understand you said: '{user_input}'. I'm processing this and learning from patterns."
            
            print(f"Mirrorcore: {response}")
            
            # Add assistant response to conversation
            conversation.append({
                "role": "assistant", 
                "content": response,
                "timestamp": datetime.utcnow().isoformat()
            })
    
    except KeyboardInterrupt:
        print("\nSession interrupted by user")
    
    # End of session - extract and store learning signals
    if len(conversation) > 2:  # Need some conversation to learn from
        print(f"\nProcessing session {session_id[:8]}... for learning signals...")
        
        # Extract signals from conversation
        signals = extractor.extract_conversation_signals(session_id, conversation)
        
        if signals:
            print(f"✓ Extracted {len(signals)} learning signals")
            
            # Store signals
            signal_ids = db_store.save_learning_signals(signals)
            print(f"✓ Stored {len(signal_ids)} learning signals")
            
            # Evaluate for persona refinements
            current_persona = db_store.load_persona_profile()
            refinements = updater.evaluate_learning_signals(
                [s.__dict__ for s in signals], current_persona, db_store
            )
            
            if refinements:
                print(f"✓ Generated {len(refinements)} persona refinement suggestions")
                
                # Apply conservative updates
                applied, suggested = updater.apply_conservative_updates(refinements, db_store)
                
                if applied > 0:
                    print(f"✓ Applied {applied} high-confidence refinements")
                if suggested > 0:
                    print(f"✓ Stored {suggested} refinement suggestions for review")
            else:
                print("✓ No clear persona refinements detected in this session")
        else:
            print("✓ No learning signals detected in this conversation")
    
    print(f"\nSession {session_id[:8]}... ended. Learning data saved.")
    print("Mirrorcore will use these insights to provide better personalized assistance.")


def handle_debug(args):
    """Handle debug command."""
    print(f"Debugging: {args.problem}")
    
    # Placeholder for debugging functionality
    # TODO: Implement debug logic using Terminal Agent
    print("Debug functionality not yet implemented")


def handle_decide(args):
    """Handle decide command."""
    print(f"Decision assistance for: {args.decision}")
    
    # Placeholder for decision assistance
    # TODO: Implement decision logic using Decision Agent
    print("Decision assistance not yet implemented")


def handle_profile(args):
    """Handle profile command."""
    if args.analyze:
        print("Analyzing recent patterns...")
    elif args.update:
        print(f"Updating profile aspect: {args.update}")
    else:
        print("Showing current profile...")
    
    # Placeholder for profile management
    # TODO: Implement profile logic using Persona Agent
    print("Profile management not yet implemented")


def handle_assess(args):
    """Handle assessment command."""
    if getattr(args, 'continue'):
        print("Continuing previous assessment...")
    else:
        print("Starting initial assessment...")
    
    # Placeholder for assessment functionality
    # TODO: Implement assessment logic using Intake Agent
    print("Assessment functionality not yet implemented")


def handle_init(args):
    """Handle init command - run the branching assessment."""
    from pathlib import Path
    from .db.store import DatabaseStore
    from .intake.scenario_engine import ScenarioEngine
    from .intake.profiler import Profiler
    
    # Check if persona already exists
    db_path = Path("data") / "mirrorcore.db"
    db_store = DatabaseStore(db_path)
    
    if db_store.persona_exists():
        print("⚠️  Warning: Persona profile already exists.")
        print("A baseline assessment has already been completed.")
        print("To reset and retake the assessment, run:")
        print("  python3 scripts/reset_assessment.py")
        print("Then run 'mirrorcore init' again.")
        return
    
    print("Starting Mirrorcore Initial Assessment...")
    print("This will help Mirrorcore understand your reasoning patterns.")
    print("\nPress Enter to begin, or Ctrl+C to cancel:")
    
    try:
        input()  # Wait for user confirmation
    except KeyboardInterrupt:
        print("\nAssessment cancelled.")
        return
    
    # Run the assessment
    try:
        engine = ScenarioEngine()
        responses = engine.run_assessment()
        
        if not responses:
            print("No responses collected. Assessment incomplete.")
            return
        
        # Analyze responses
        print("\nAnalyzing your responses...")
        profiler = Profiler()
        persona_traits = profiler.analyze_responses(responses)
        
        # Convert to dict format for storage
        persona_dict = {}
        for trait_name, trait in persona_traits.items():
            persona_dict[trait_name] = {
                "value": trait.value,
                "confidence": trait.confidence,
                "evidence_count": trait.evidence_count,
                "contributing_responses": trait.contributing_responses
            }
        
        # Save to database
        print("Saving your persona profile...")
        trait_ids = db_store.save_persona_traits(persona_dict)
        
        # Save raw responses
        response_dicts = []
        for response in responses:
            response_dict = {
                "assessment_session_id": response.assessment_session_id,
                "question_id": response.question_id,
                "question_type": response.question_type.value,
                "selected_option_id": response.selected_option_id,
                "custom_response": response.custom_response,
                "explanation": response.explanation,
                "trigger_reason": response.trigger_reason,
                "order_index": response.order_index
            }
            response_dicts.append(response_dict)
        
        memory_ids = db_store.save_assessment_responses(response_dicts)
        
        # Display results
        print("\n" + "="*60)
        print("ASSESSMENT RESULTS")
        print("="*60)
        
        # Show improved summary
        summary = profiler.generate_assessment_summary(persona_traits, responses)
        print(summary)
        
        print(f"\n✓ Saved {len(trait_ids)} persona traits")
        print(f"✓ Saved {len(memory_ids)} raw assessment responses")
        print(f"✓ Assessment session ID: {responses[0].assessment_session_id if responses else 'unknown'}")
        
        # Show confidence summary
        avg_confidence = sum(t.confidence for t in persona_traits.values()) / len(persona_traits)
        confidence_pct = int(avg_confidence * 100)
        print(f"✓ Average confidence: {confidence_pct}%")
        
        print("\nYour baseline persona profile is now ready!")
        print("Mirrorcore will use this profile to provide personalized assistance.")
        
        db_store.close()
        
    except Exception as e:
        print(f"\n❌ Error during assessment: {e}")
        print("Your progress has not been saved.")
        print("You can safely restart the assessment.")
        return


def handle_memory(args):
    """Handle memory command."""
    print(f"Memory action: {args.action}")
    
    # Placeholder for memory management
    # TODO: Implement memory logic using Memory Agent
    print("Memory management not yet implemented")


def handle_status(args):
    """Handle status command."""
    print("Mirrorcore System Status")
    print("=" * 30)
    
    try:
        config = get_config()
        print(f"✓ Configuration loaded")
        
        db_store = DatabaseStore()
        stats = db_store.get_database_stats()
        print("✓ Database connected")
        print(f"  - Persona traits: {stats['persona_traits']}")
        print(f"  - Memory entries: {stats['memory_entries']}")
        print(f"  - Terminal incidents: {stats['terminal_incidents']}")
        print(f"  - Decision records: {stats['decision_records']}")
        print(f"  - Total sessions: {stats['total_sessions']}")
            
        print(f"Version: {__version__}")
        
    except Exception as e:
        print(f"✗ Status check failed: {e}")


def handle_config(args):
    """Handle configuration command."""
    try:
        config = get_config()
        
        if args.get:
            value = config.get(args.get, "Not found")
            print(f"{args.get}: {value}")
        elif args.set:
            key, value = args.set
            print(f"Setting {key} = {value}")
            print("Configuration update not yet implemented")
        else:
            print("Current configuration:")
            print(config)
            
    except Exception as e:
        print(f"Configuration error: {e}")


def main():
    """Main entry point."""
    parser = create_parser()
    args = parser.parse_args()
    
    # Initialize database first
    try:
        db_path = Path("data") / "mirrorcore.db"
        db_store = DatabaseStore(db_path)
        db_store.initialize_database()
        if args.verbose:
            print("✓ Database initialized successfully")
    except Exception as e:
        print(f"✗ Database initialization failed: {e}")
        sys.exit(1)
    
    # Handle no command (default to interactive)
    if not args.command:
        args.command = "interactive"
    
    # Check for persona existence (only for commands that require initialized persona)
    persona_required_commands = ["interactive", "debug", "decide", "profile", "assess", "memory"]
    
    if args.command in persona_required_commands:
        if db_store.persona_exists():
            # Load persona profile
            persona_profile = db_store.load_persona_profile()
            if args.verbose:
                print("✓ Persona profile loaded successfully.")
        else:
            print("Mirrorcore requires an initial reasoning assessment before first use.")
            print("Run: mirrorcore init")
            sys.exit(1)
    
    # Route to appropriate handler
    handlers = {
        "interactive": handle_interactive,
        "debug": handle_debug,
        "decide": handle_decide,
        "profile": handle_profile,
        "assess": handle_assess,
        "init": handle_init,
        "memory": handle_memory,
        "status": handle_status,
        "config": handle_config
    }
    
    handler = handlers.get(args.command)
    if handler:
        try:
            handler(args)
        except KeyboardInterrupt:
            print("\nOperation cancelled by user")
            sys.exit(1)
        except Exception as e:
            print(f"Error: {e}")
            if args.verbose:
                import traceback
                traceback.print_exc()
            sys.exit(1)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
