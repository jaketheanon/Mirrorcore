"""
Mirrorcore Database Models

This module defines the database models and ORM layer for Mirrorcore.
"""

import sqlite3
import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional, Union


class DatabaseManager:
    """Main database manager for Mirrorcore."""
    
    def __init__(self, db_path: Optional[Path] = None):
        if db_path is None:
            from ..config import get_database_path
            db_path = get_database_path()
        
        self.db_path = db_path
        self._connection = None
    
    def connect(self) -> sqlite3.Connection:
        """Connect to the database."""
        if self._connection is None:
            # Ensure directory exists
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            
            self._connection = sqlite3.connect(str(self.db_path))
            self._connection.row_factory = sqlite3.Row  # Enable dict-like access
            
            # Enable foreign keys
            self._connection.execute("PRAGMA foreign_keys = ON")
            
            # Initialize tables if needed
            initialize_database(self._connection)
        
        return self._connection
    
    def close(self):
        """Close the database connection."""
        if self._connection:
            self._connection.close()
            self._connection = None
    
    def is_connected(self) -> bool:
        """Check if database is connected."""
        return self._connection is not None
    
    def execute(self, query: str, params: tuple = ()) -> sqlite3.Cursor:
        """Execute a database query."""
        conn = self.connect()
        return conn.execute(query, params)
    
    def fetchone(self, query: str, params: tuple = ()) -> Optional[sqlite3.Row]:
        """Execute query and fetch one result."""
        cursor = self.execute(query, params)
        return cursor.fetchone()
    
    def fetchall(self, query: str, params: tuple = ()) -> List[sqlite3.Row]:
        """Execute query and fetch all results."""
        cursor = self.execute(query, params)
        return cursor.fetchall()
    
    def commit(self):
        """Commit the current transaction."""
        if self._connection:
            self._connection.commit()
    
    def rollback(self):
        """Rollback the current transaction."""
        if self._connection:
            self._connection.rollback()


def initialize_database(conn: sqlite3.Connection):
    """Initialize database tables with the required schema."""
    
    # 1) persona_profile table - Stores stable traits about the user
    conn.execute("""
        CREATE TABLE IF NOT EXISTS persona_profile (
            id TEXT PRIMARY KEY,
            created_at TIMESTAMP NOT NULL,
            updated_at TIMESTAMP NOT NULL,
            trait_name TEXT NOT NULL,
            trait_value TEXT NOT NULL,
            confidence REAL NOT NULL DEFAULT 0.0,
            source TEXT NOT NULL CHECK (source IN ('stated', 'inferred', 'observed', 'assessment', 'learning'))
        )
    """)
    
    # 2) memory_entries table - Stores episodic memories from conversations and actions
    conn.execute("""
        CREATE TABLE IF NOT EXISTS memory_entries (
            id TEXT PRIMARY KEY,
            timestamp TIMESTAMP NOT NULL,
            memory_type TEXT NOT NULL,
            content TEXT NOT NULL,
            source_module TEXT NOT NULL,
            confidence REAL NOT NULL DEFAULT 0.0,
            tags TEXT
        )
    """)
    
    # 3) terminal_incidents table - Stores troubleshooting experiences
    conn.execute("""
        CREATE TABLE IF NOT EXISTS terminal_incidents (
            id TEXT PRIMARY KEY,
            timestamp TIMESTAMP NOT NULL,
            command TEXT NOT NULL,
            error_message TEXT NOT NULL,
            root_cause TEXT,
            solution TEXT,
            success BOOLEAN NOT NULL DEFAULT FALSE,
            notes TEXT
        )
    """)
    
    # 4) decision_history table - Stores analyzed decisions and outcomes
    conn.execute("""
        CREATE TABLE IF NOT EXISTS decision_history (
            id TEXT PRIMARY KEY,
            timestamp TIMESTAMP NOT NULL,
            problem_description TEXT NOT NULL,
            options TEXT NOT NULL,  -- JSON array of options
            recommended_option TEXT NOT NULL,
            reasoning TEXT NOT NULL,
            outcome TEXT,
            confidence REAL NOT NULL DEFAULT 0.0
        )
    """)
    
    # 5) session_logs table - Tracks individual assistant sessions
    conn.execute("""
        CREATE TABLE IF NOT EXISTS session_logs (
            id TEXT PRIMARY KEY,
            session_start TIMESTAMP NOT NULL,
            session_end TIMESTAMP,
            interaction_count INTEGER NOT NULL DEFAULT 0,
            notes TEXT
        )
    """)
    
    # Create indexes for performance
    indexes = [
        "CREATE INDEX IF NOT EXISTS idx_persona_profile_trait_name ON persona_profile(trait_name)",
        "CREATE INDEX IF NOT EXISTS idx_persona_profile_updated_at ON persona_profile(updated_at)",
        "CREATE INDEX IF NOT EXISTS idx_memory_entries_timestamp ON memory_entries(timestamp)",
        "CREATE INDEX IF NOT EXISTS idx_memory_entries_type ON memory_entries(memory_type)",
        "CREATE INDEX IF NOT EXISTS idx_memory_entries_source_module ON memory_entries(source_module)",
        "CREATE INDEX IF NOT EXISTS idx_terminal_incidents_timestamp ON terminal_incidents(timestamp)",
        "CREATE INDEX IF NOT EXISTS idx_terminal_incidents_success ON terminal_incidents(success)",
        "CREATE INDEX IF NOT EXISTS idx_decision_history_timestamp ON decision_history(timestamp)",
        "CREATE INDEX IF NOT EXISTS idx_decision_history_confidence ON decision_history(confidence)",
        "CREATE INDEX IF NOT EXISTS idx_session_logs_session_start ON session_logs(session_start)"
    ]
    
    for index_sql in indexes:
        conn.execute(index_sql)


# Simple helper functions for database operations
def get_db_connection(db_path: Optional[Path] = None) -> sqlite3.Connection:
    """Get a database connection."""
    if db_path is None:
        from ..config import get_database_path
        db_path = get_database_path()
    
    # Ensure directory exists
    db_path.parent.mkdir(parents=True, exist_ok=True)
    
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row  # Enable dict-like access
    
    # Enable foreign keys
    conn.execute("PRAGMA foreign_keys = ON")
    
    # Initialize tables if needed
    initialize_database(conn)
    
    return conn


# Helper functions for inserting data into each table
def insert_persona_trait(conn: sqlite3.Connection, trait_name: str, trait_value: str, 
                       confidence: float, source: str) -> str:
    """Insert a persona trait."""
    import uuid
    from datetime import datetime
    
    trait_id = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()
    
    query = """
        INSERT INTO persona_profile 
        (id, created_at, updated_at, trait_name, trait_value, confidence, source)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """
    
    conn.execute(query, (trait_id, now, now, trait_name, trait_value, confidence, source))
    conn.commit()
    
    return trait_id


def insert_memory_entry(conn: sqlite3.Connection, memory_type: str, content: str, 
                        source_module: str, confidence: float, tags: str = None) -> str:
    """Insert a memory entry."""
    import uuid
    from datetime import datetime
    
    memory_id = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()
    
    query = """
        INSERT INTO memory_entries 
        (id, timestamp, memory_type, content, source_module, confidence, tags)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """
    
    conn.execute(query, (memory_id, now, memory_type, content, source_module, confidence, tags))
    conn.commit()
    
    return memory_id


def insert_terminal_incident(conn: sqlite3.Connection, command: str, error_message: str,
                           root_cause: str = None, solution: str = None, 
                           success: bool = False, notes: str = None) -> str:
    """Insert a terminal incident."""
    import uuid
    from datetime import datetime
    
    incident_id = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()
    
    query = """
        INSERT INTO terminal_incidents 
        (id, timestamp, command, error_message, root_cause, solution, success, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """
    
    conn.execute(query, (incident_id, now, command, error_message, root_cause, solution, success, notes))
    conn.commit()
    
    return incident_id


def insert_decision_record(conn: sqlite3.Connection, problem_description: str, options: str,
                         recommended_option: str, reasoning: str, outcome: str = None,
                         confidence: float = 0.0) -> str:
    """Insert a decision record."""
    import uuid
    from datetime import datetime
    
    decision_id = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()
    
    query = """
        INSERT INTO decision_history 
        (id, timestamp, problem_description, options, recommended_option, reasoning, outcome, confidence)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """
    
    conn.execute(query, (decision_id, now, problem_description, options, recommended_option, reasoning, outcome, confidence))
    conn.commit()
    
    return decision_id


def insert_session_log(conn: sqlite3.Connection, session_start: str, interaction_count: int = 0,
                      session_end: str = None, notes: str = None) -> str:
    """Insert a session log."""
    import uuid
    
    session_id = str(uuid.uuid4())
    
    query = """
        INSERT INTO session_logs 
        (id, session_start, session_end, interaction_count, notes)
        VALUES (?, ?, ?, ?, ?)
    """
    
    conn.execute(query, (session_id, session_start, session_end, interaction_count, notes))
    conn.commit()
    
    return session_id


# Convenience function to get database manager
def get_database_manager() -> DatabaseManager:
    """Get a database manager instance."""
    return DatabaseManager()
