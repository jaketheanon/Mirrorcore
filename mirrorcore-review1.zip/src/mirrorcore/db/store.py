"""
Database Store Layer

This module provides high-level database operations and abstraction using lightweight SQLite.
"""

import json
from typing import Dict, Any, List, Optional
from pathlib import Path
from .models import (
    get_db_connection, 
    initialize_database,
    insert_persona_trait,
    insert_memory_entry,
    insert_terminal_incident,
    insert_decision_record,
    insert_session_log
)


class DatabaseStore:
    """Lightweight database store interface for Mirrorcore."""
    
    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = db_path
        self._connection = None
    
    def get_db_connection(self):
        """Get a database connection, creating it if needed."""
        if self._connection is None:
            self._connection = get_db_connection(self.db_path)
        return self._connection
    
    def initialize_database(self):
        """Initialize the database with all required tables."""
        conn = self.get_db_connection()
        initialize_database(conn)
        return True
    
    def close(self):
        """Close database connection."""
        if self._connection:
            self._connection.close()
            self._connection = None
    
    # Persona profile operations
    def add_persona_trait(self, trait_name: str, trait_value: str, confidence: float, source: str) -> str:
        """Add a persona trait to the database."""
        conn = self.get_db_connection()
        return insert_persona_trait(conn, trait_name, trait_value, confidence, source)
    
    def get_persona_traits(self, trait_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get persona traits, optionally filtered by trait name."""
        conn = self.get_db_connection()
        
        if trait_name:
            query = "SELECT * FROM persona_profile WHERE trait_name = ? ORDER BY updated_at DESC"
            rows = conn.execute(query, (trait_name,)).fetchall()
        else:
            query = "SELECT * FROM persona_profile ORDER BY updated_at DESC"
            rows = conn.execute(query).fetchall()
        
        return [dict(row) for row in rows]
    
    def persona_exists(self) -> bool:
        """Check if any persona profile exists in the database."""
        conn = self.get_db_connection()
        
        query = "SELECT COUNT(*) as count FROM persona_profile"
        result = conn.execute(query).fetchone()
        
        return result['count'] > 0
    
    def load_persona_profile(self) -> Dict[str, Dict[str, Any]]:
        """Load all persona traits in structured dictionary format."""
        conn = self.get_db_connection()
        
        query = "SELECT trait_name, trait_value, confidence, source FROM persona_profile ORDER BY updated_at DESC"
        rows = conn.execute(query).fetchall()
        
        persona_profile = {}
        
        for row in rows:
            trait_name = row['trait_name']
            
            # If trait already exists, keep the most recent one (first in ordered results)
            if trait_name not in persona_profile:
                persona_profile[trait_name] = {
                    "value": row['trait_value'],
                    "confidence": row['confidence'],
                    "source": row['source']
                }
        
        return persona_profile
    
    def save_assessment_responses(self, responses: List[Dict[str, Any]]) -> List[str]:
        """Save raw assessment responses as memory entries with session grouping."""
        saved_ids = []
        
        for response in responses:
            # Create a structured content for the response
            content = {
                "assessment_session_id": response.get("assessment_session_id"),
                "question_id": response.get("question_id"),
                "question_type": response.get("question_type"),
                "selected_option_id": response.get("selected_option_id"),
                "custom_response": response.get("custom_response"),
                "explanation": response.get("explanation"),
                "trigger_reason": response.get("trigger_reason"),
                "order_index": response.get("order_index")
            }
            
            # Include session ID in tags for easy retrieval
            session_id = response.get("assessment_session_id", "unknown")
            question_type = response.get("question_type", "unknown")
            
            # Save as memory entry
            memory_id = self.add_memory_entry(
                memory_type="initial_assessment_response",
                content=json.dumps(content),  # Serialize as JSON for storage
                source_module="intake",
                confidence=0.9,  # High confidence in recorded responses
                tags=f"assessment,response,{question_type},session_{session_id}"
            )
            saved_ids.append(memory_id)
        
        return saved_ids
    
    def save_persona_traits(self, persona_traits: Dict[str, Any]) -> List[str]:
        """Save inferred persona traits to database."""
        saved_ids = []
        
        for trait_name, trait_data in persona_traits.items():
            if isinstance(trait_data, dict):
                trait_value = trait_data.get("value", 0.5)
                confidence = trait_data.get("confidence", 0.0)
            else:
                # Handle simple numeric values
                trait_value = float(trait_data)
                confidence = 0.5  # Default confidence for simple values
            
            trait_id = self.add_persona_trait(
                trait_name=trait_name,
                trait_value=str(trait_value),
                confidence=confidence,
                source="inferred"
            )
            saved_ids.append(trait_id)
        
        return saved_ids
    
    def save_persona_traits(self, persona_traits: Dict[str, Any]) -> List[str]:
        """Save inferred persona traits to database."""
        saved_ids = []
        
        for trait_name, trait_data in persona_traits.items():
            # Handle both PersonaTrait objects and simple values
            if hasattr(trait_data, 'value'):
                # PersonaTrait object
                trait_value = trait_data.value
                confidence = trait_data.confidence
                source = "assessment"
            else:
                # Simple value
                trait_value = trait_data.get("value", trait_data)
                confidence = trait_data.get("confidence", 0.7)
                source = trait_data.get("source", "assessment")
            
            trait_id = self.add_persona_trait(
                trait_name=trait_name,
                trait_value=str(trait_value),
                confidence=confidence,
                source=source
            )
            saved_ids.append(trait_id)
        
        return saved_ids
    
    def save_learning_signals(self, signals: List[Dict[str, Any]]) -> List[str]:
        """Save conversation learning signals as memory entries."""
        saved_ids = []
        
        for signal in signals:
            # Convert to dict if it's a LearningSignal object
            if hasattr(signal, 'to_dict'):
                signal_data = signal.to_dict()
            else:
                signal_data = signal
            
            # Save learning signal as memory entry
            memory_id = self.add_memory_entry(
                memory_type="learning_signal",
                content=json.dumps(signal_data),  # Serialize as JSON
                source_module=signal_data.get("source_module", "conversation"),
                confidence=signal_data.get("confidence", 0.5),
                tags=f"learning,signal,{signal_data.get('signal_type', 'unknown')}"
            )
            saved_ids.append(memory_id)
        
        return saved_ids
    
    def fetch_learning_signals(self, signal_type: Optional[str] = None, 
                           session_id: Optional[str] = None,
                           days_back: int = 30) -> List[Dict[str, Any]]:
        """Fetch learning signals with optional filtering."""
        # Get all learning signal memories
        memories = self.search_memories("", limit=100)
        
        filtered_signals = []
        cutoff_date = datetime.utcnow() - timedelta(days=days_back)
        
        for memory in memories:
            if memory.get("memory_type") != "learning_signal":
                continue
            
            # Parse signal data
            try:
                signal_data = json.loads(memory.get("content", "{}"))
            except:
                continue
            
            # Filter by signal type
            if signal_type and signal_data.get("signal_type") != signal_type:
                continue
            
            # Filter by session ID
            if session_id and signal_data.get("session_id") != session_id:
                continue
            
            # Filter by recency
            try:
                signal_time = datetime.fromisoformat(signal_data.get("timestamp", ""))
                if signal_time < cutoff_date:
                    continue
            except:
                continue
            
            filtered_signals.append(signal_data)
        
        return filtered_signals
    
    def get_persona_refinement_suggestions(self, days_back: int = 30) -> List[Dict[str, Any]]:
        """Get stored persona refinement suggestions."""
        # Get refinement memories
        memories = self.search_memories("", limit=100)
        
        refinements = []
        cutoff_date = datetime.utcnow() - timedelta(days=days_back)
        
        for memory in memories:
            if memory.get("memory_type") != "persona_refinement":
                continue
            
            # Parse refinement data
            try:
                refinement_data = json.loads(memory.get("content", "{}"))
                
                # Filter by recency
                try:
                    refinement_time = datetime.fromisoformat(refinement_data.get("timestamp", ""))
                    if refinement_time >= cutoff_date:
                        refinements.append(refinement_data)
                except:
                    continue
            except:
                continue
        
        return refinements
    
    # Memory operations
    def add_memory_entry(self, memory_type: str, content: str, source_module: str, 
                        confidence: float, tags: str = None) -> str:
        """Add a memory entry to the database."""
        conn = self.get_db_connection()
        return insert_memory_entry(conn, memory_type, content, source_module, confidence, tags)
    
    def search_memories(self, query_text: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Search memory entries for matching content."""
        conn = self.get_db_connection()
        
        search_pattern = f"%{query_text}%"
        query = """
            SELECT * FROM memory_entries 
            WHERE content LIKE ? OR tags LIKE ?
            ORDER BY timestamp DESC
            LIMIT ?
        """
        
        rows = conn.execute(query, (search_pattern, search_pattern, limit)).fetchall()
        return [dict(row) for row in rows]
    
    def get_memories_by_type(self, memory_type: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Get memory entries by type."""
        conn = self.get_db_connection()
        
        query = "SELECT * FROM memory_entries WHERE memory_type = ? ORDER BY timestamp DESC LIMIT ?"
        rows = conn.execute(query, (memory_type, limit)).fetchall()
        
        return [dict(row) for row in rows]
    
    # Terminal incident operations
    def add_terminal_incident(self, command: str, error_message: str, root_cause: str = None,
                             solution: str = None, success: bool = False, notes: str = None) -> str:
        """Add a terminal incident to the database."""
        conn = self.get_db_connection()
        return insert_terminal_incident(conn, command, error_message, root_cause, solution, success, notes)
    
    def get_terminal_incidents(self, success: Optional[bool] = None, limit: int = 50) -> List[Dict[str, Any]]:
        """Get terminal incidents, optionally filtered by success status."""
        conn = self.get_db_connection()
        
        if success is not None:
            query = "SELECT * FROM terminal_incidents WHERE success = ? ORDER BY timestamp DESC LIMIT ?"
            rows = conn.execute(query, (success, limit)).fetchall()
        else:
            query = "SELECT * FROM terminal_incidents ORDER BY timestamp DESC LIMIT ?"
            rows = conn.execute(query, (limit,)).fetchall()
        
        return [dict(row) for row in rows]
    
    def search_terminal_incidents(self, search_text: str, limit: int = 20) -> List[Dict[str, Any]]:
        """Search terminal incidents for matching commands or errors."""
        conn = self.get_db_connection()
        
        search_pattern = f"%{search_text}%"
        query = """
            SELECT * FROM terminal_incidents 
            WHERE command LIKE ? OR error_message LIKE ? OR solution LIKE ?
            ORDER BY timestamp DESC
            LIMIT ?
        """
        
        rows = conn.execute(query, (search_pattern, search_pattern, search_pattern, limit)).fetchall()
        return [dict(row) for row in rows]
    
    # Decision history operations
    def add_decision_record(self, problem_description: str, options: str, recommended_option: str,
                          reasoning: str, outcome: str = None, confidence: float = 0.0) -> str:
        """Add a decision record to the database."""
        conn = self.get_db_connection()
        return insert_decision_record(conn, problem_description, options, recommended_option, reasoning, outcome, confidence)
    
    def get_decision_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get decision history."""
        conn = self.get_db_connection()
        
        query = "SELECT * FROM decision_history ORDER BY timestamp DESC LIMIT ?"
        rows = conn.execute(query, (limit,)).fetchall()
        
        return [dict(row) for row in rows]
    
    def search_decisions(self, search_text: str, limit: int = 20) -> List[Dict[str, Any]]:
        """Search decision history for matching problems or solutions."""
        conn = self.get_db_connection()
        
        search_pattern = f"%{search_text}%"
        query = """
            SELECT * FROM decision_history 
            WHERE problem_description LIKE ? OR recommended_option LIKE ? OR reasoning LIKE ?
            ORDER BY timestamp DESC
            LIMIT ?
        """
        
        rows = conn.execute(query, (search_pattern, search_pattern, search_pattern, limit)).fetchall()
        return [dict(row) for row in rows]
    
    # Session log operations
    def start_session(self, notes: str = None) -> str:
        """Start a new session and return the session ID."""
        from datetime import datetime
        
        session_start = datetime.utcnow().isoformat()
        conn = self.get_db_connection()
        
        return insert_session_log(conn, session_start, interaction_count=0, notes=notes)
    
    def end_session(self, session_id: str, interaction_count: int = 0, notes: str = None):
        """End a session with final interaction count and notes."""
        from datetime import datetime
        
        session_end = datetime.utcnow().isoformat()
        conn = self.get_db_connection()
        
        query = """
            UPDATE session_logs 
            SET session_end = ?, interaction_count = ?, notes = ?
            WHERE id = ?
        """
        
        conn.execute(query, (session_end, interaction_count, notes, session_id))
        conn.commit()
    
    def get_recent_sessions(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Get recent session logs."""
        conn = self.get_db_connection()
        
        query = "SELECT * FROM session_logs ORDER BY session_start DESC LIMIT ?"
        rows = conn.execute(query, (limit,)).fetchall()
        
        return [dict(row) for row in rows]
    
    # Statistics and analytics
    def get_database_stats(self) -> Dict[str, Any]:
        """Get comprehensive database statistics."""
        conn = self.get_db_connection()
        
        stats = {}
        
        # Persona traits count
        stats['persona_traits'] = conn.execute("SELECT COUNT(*) as count FROM persona_profile").fetchone()['count']
        
        # Memory entries count
        stats['memory_entries'] = conn.execute("SELECT COUNT(*) as count FROM memory_entries").fetchone()['count']
        
        # Terminal incidents count
        stats['terminal_incidents'] = conn.execute("SELECT COUNT(*) as count FROM terminal_incidents").fetchone()['count']
        stats['successful_incidents'] = conn.execute("SELECT COUNT(*) as count FROM terminal_incidents WHERE success = TRUE").fetchone()['count']
        
        # Decision records count
        stats['decision_records'] = conn.execute("SELECT COUNT(*) as count FROM decision_history").fetchone()['count']
        
        # Session count
        stats['total_sessions'] = conn.execute("SELECT COUNT(*) as count FROM session_logs").fetchone()['count']
        
        # Average session duration (for completed sessions)
        avg_duration_result = conn.execute("""
            SELECT AVG(CAST(strftime('%s', session_end) - strftime('%s', session_start) AS INTEGER)) as avg_duration
            FROM session_logs 
            WHERE session_end IS NOT NULL
        """).fetchone()
        
        stats['average_session_duration_seconds'] = avg_duration_result['avg_duration'] or 0
        
        return stats
