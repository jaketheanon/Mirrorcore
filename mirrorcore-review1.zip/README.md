# Mirrorcore

A local-first Python CLI application that serves as a private persistent reasoning assistant.

## Overview

Mirrorcore models your thinking patterns, decision logic, troubleshooting habits, and communication style to provide personalized assistance. It operates as a continuously learning reasoning agent with persistent identity modeling, episodic memory, and reflective learning.

## Features

- **Initial Assessment** - Branching questionnaire to understand your reasoning patterns
- **Terminal Troubleshooting** - Analyze and diagnose command-line issues using your historical problem-solving patterns
- **Decision Reasoning** - Get decision support based on your values, risk tolerance, and decision style
- **Learning from Conversations** - Extract and model reasoning patterns from ongoing interactions
- **Persona Modeling** - Continuously refine understanding of your communication style and cognitive preferences

## Architecture

Mirrorcore follows a modular agent-based architecture with specialized agents for different capabilities:

- **Intake Agent** - Initial user assessment and scenario-based profiling
- **Memory Agent** - Episodic memory extraction, retrieval, and updates
- **Persona Agent** - Voice, values, and decision-making style modeling
- **Terminal Agent** - Command-line parsing, diagnosis, and resolution
- **Decision Agent** - Reasoning support and tradeoff analysis
- **LLM Agent** - Language model interaction abstraction

## Installation

Mirrorcore uses Python's standard library only. No external dependencies required.

### Option 1: Run from source
```bash
# Clone or download the repository
git clone https://github.com/your-repo/mirrorcore.git
cd mirrorcore

# Run directly with Python module
PYTHONPATH=src python3 -m mirrorcore --help
```

### Option 2: Install in development mode
```bash
# Clone or download the repository
git clone https://github.com/your-repo/mirrorcore.git
cd mirrorcore

# Install in development mode (creates editable install)
pip install -e .

# Now you can run from anywhere
mirrorcore --help
```

## First-Time Setup

1. **Initialize Database**
   ```bash
   mirrorcore init
   ```
   This runs the initial reasoning assessment to establish your persona profile.

2. **Start Interactive Session**
   ```bash
   mirrorcore interactive
   ```
   Begin conversing with Mirrorcore. It will learn from your interaction patterns over time.

3. **Check Status**
   ```bash
   mirrorcore status
   ```
   View system status, persona traits, and learning progress.

## Available Commands

- `mirrorcore init` - Run initial reasoning assessment
- `mirrorcore interactive` - Start interactive learning session
- `mirrorcore debug "<command>"` - Debug terminal issues
- `mirrorcore decide "<question>"` - Get decision assistance
- `mirrorcore profile` - View your persona profile
- `mirrorcore assess` - Continue previous assessment
- `mirrorcore memory` - Memory management
- `mirrorcore status` - Show system status
- `mirrorcore config` - Configuration management

## Learning System

Mirrorcore includes a conservative ongoing learning system that:

- **Extracts Signals** - Identifies patterns in your communication style, decision preferences, and reasoning approaches
- **Requires Evidence** - Minimum of 3 reinforcing signals before suggesting persona updates
- **Conservative Updates** - Maximum 15% change per update, prefers stability
- **Session-Based Learning** - Groups all signals from a conversation for analysis
- **JSON Storage** - All learning data stored as structured, reconstructable JSON

## Testing

Run the test suite:
```bash
PYTHONPATH=src python3 -m pytest tests/
```

## Privacy

- All data stored locally in SQLite database
- No external data transmission required
- Learning signals and persona updates are traceable and reversible
- Full control over data retention and deletion
- Assessment responses and persona traits stored locally

## Development

See `docs/` for detailed documentation on architecture, memory models, and development guidelines.

## Testing

```bash
# Run tests
python -m pytest tests/

# Run specific intake tests
python -m pytest tests/test_intake.py
```

## License

MIT License - see LICENSE file for details.
